package com.xufree.learning.redis.entity;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class NullValueResultDO{
    private String name;
}